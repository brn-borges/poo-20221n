package br.edu.fatecfranca.ex1;

public class TestaAluno {

    public static void main(String[] args) {
        
        Aluno num1 = new Aluno(1, "Bruno Borges", 24, 0,8);
        
        num1.notaFinal();
        num1.passou();
        num1.dadosAluno();
        
    }
    
}
